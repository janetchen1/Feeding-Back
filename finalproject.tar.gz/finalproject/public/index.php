<?php
	
	/**
     * index.php
     *
     * Janet Chen
     * Computer Science 50
     * Final Project
     * 
     * Home page, redirects to displaycomments.php.
     */
     
	require("../includes/config.php");
	redirect("/displaycomments.php");
?>
