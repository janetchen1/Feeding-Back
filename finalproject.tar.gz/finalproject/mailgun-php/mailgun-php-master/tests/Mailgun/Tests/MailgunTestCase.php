<?PHP

namespace Mailgun\Tests;

abstract class MailgunTestCase extends \PHPUnit_Framework_TestCase
{
}
