<?php
namespace Mailgun\Connection\Exceptions;

class MissingRequiredParameters extends \Exception{}
